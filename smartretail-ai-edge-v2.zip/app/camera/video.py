import cv2
import time
import threading
from pathlib import Path

class VideoCamera:
    """
    Continuous thread-safe video camera stream.
    Supports looping local retail video files, webcams (0, 1), and RTSP CCTV feeds.
    """
    def __init__(self, source):
        self.source = source
        self.is_numeric = isinstance(source, int) or (isinstance(source, str) and source.isdigit())
        self.cap = None
        self.lock = threading.Lock()
        self.running = True
        self.last_frame = None
        self.fps = 30
        
        self._open_stream()

    def _open_stream(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

        if self.is_numeric:
            src = int(self.source)
            self.cap = cv2.VideoCapture(src)
            if not self.cap.isOpened():
                self.cap = cv2.VideoCapture(src, cv2.CAP_DSHOW)
        else:
            src_str = str(self.source)
            self.cap = cv2.VideoCapture(src_str)
            if not self.cap.isOpened():
                alt_path = Path("videos/store.mp4")
                if alt_path.exists():
                    self.cap = cv2.VideoCapture(str(alt_path))

        if self.cap is not None and self.cap.isOpened():
            val = self.cap.get(cv2.CAP_PROP_FPS)
            if val and val > 0:
                self.fps = min(60.0, max(15.0, val))

    def set_source(self, new_source):
        with self.lock:
            if self.cap is not None:
                self.cap.release()
                self.cap = None
            self.source = new_source
            self.is_numeric = isinstance(new_source, int) or (isinstance(new_source, str) and str(new_source).strip().isdigit())
            self.last_frame = None
            self._open_stream()
            return self.cap is not None and self.cap.isOpened()

    def get_source_info(self):
        return {
            "source": str(self.source),
            "is_webcam": self.is_numeric,
            "fps": round(self.fps, 1),
            "is_opened": self.cap is not None and self.cap.isOpened()
        }

    def get_frame(self):
        with self.lock:
            if not self.cap or not self.cap.isOpened():
                self._open_stream()
                if not self.cap or not self.cap.isOpened():
                    return None

            ok, frame = self.cap.read()
            if not ok:
                # If file video ended, loop seamlessly back to start
                if not self.is_numeric:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, frame = self.cap.read()
                
            if ok:
                self.last_frame = frame
                return frame
            return self.last_frame

    def frames(self):
        while self.running:
            frame = self.get_frame()
            if frame is not None:
                yield frame
            time.sleep(1.0 / self.fps)

    def release(self):
        self.running = False
        with self.lock:
            if self.cap:
                self.cap.release()
