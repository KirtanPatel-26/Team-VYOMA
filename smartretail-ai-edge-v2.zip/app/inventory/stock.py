class StockAnalyzer:
    def __init__(self, catalog):
        self.catalog = catalog

    def analyze(self, counts):
        output = []
        total_items = 0
        total_value = 0.0

        for product in self.catalog.all():
            name = product["name"]
            current = int(counts.get(name, 0))
            minimum = int(product.get("minimum_stock", 2))
            price = float(product.get("price", 0.0))
            shelf_zone = product.get("target_shelf_zone", "Shelf")

            if current == 0:
                status = "OUT_OF_STOCK"
                health = 0
            elif current <= minimum:
                status = "LOW_STOCK"
                health = int((current / (minimum * 2)) * 100)
            else:
                status = "IN_STOCK"
                health = 100

            total_items += current
            total_value += current * price

            output.append({
                "product_id": product["id"],
                "product_name": name,
                "category": product.get("category", "General"),
                "price": price,
                "stock": current,
                "minimum_stock": minimum,
                "status": status,
                "health_percentage": health,
                "shelf_zone": shelf_zone,
                "total_value": round(current * price, 2)
            })

        return {
            "items": output,
            "total_detected_units": total_items,
            "total_inventory_value": round(total_value, 2),
            "stock_health_score": round(sum(i["health_percentage"] for i in output) / max(1, len(output)), 1)
        }
