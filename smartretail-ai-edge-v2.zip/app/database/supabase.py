import os
import time
from datetime import datetime

class SupabaseDatabase:
    """
    Supabase Cloud Sync Engine.
    Handles cloud synchronization of edge retail telemetry, store metrics, shelf compliance, and incident alerts.
    """
    def __init__(self, url=None, key=None, store_code="STORE_001"):
        self.url = (url or os.getenv("SUPABASE_URL", "")).strip()
        self.key = (key or os.getenv("SUPABASE_KEY", "")).strip()
        self.store_code = store_code
        self.client = None
        self.last_sync_time = None
        self.last_sync_status = "Not Connected"
        self.synced_counts = {"traffic": 0, "inventory": 0, "queue": 0, "alerts": 0, "shelf": 0}
        
        self.connect()

    def connect(self, url=None, key=None):
        if url:
            self.url = url.strip()
        if key:
            self.key = key.strip()

        if self.url and self.key:
            try:
                from supabase import create_client
                self.client = create_client(self.url, self.key)
                self.last_sync_status = "Connected"
                # Ensure store exists in stores table to satisfy foreign keys
                self._ensure_store_exists()
                return True
            except Exception as e:
                self.client = None
                self.last_sync_status = f"Error: {str(e)}"
                return False
        else:
            self.client = None
            self.last_sync_status = "Disconnected (No API Key)"
            return False

    def _ensure_store_exists(self):
        if not self.client:
            return
        try:
            self.client.table("stores").upsert({
                "store_code": self.store_code,
                "name": "SmartRetail Flagship",
                "location": "Indiranagar, 100ft Road",
                "city": "Bengaluru",
                "tier": "Tier-1",
                "total_counters": 4
            }, on_conflict="store_code").execute()
        except Exception as e:
            print(f"[Supabase] Store auto-upsert note: {e}")

    def disconnect(self):
        """
        Disconnects the Supabase client and clears active credentials.
        """
        self.client = None
        self.url = ""
        self.key = ""
        self.last_sync_status = "Disconnected"
        return {"success": True, "message": "Disconnected from Supabase Cloud."}

    @property
    def enabled(self):
        return self.client is not None

    def test_connection(self):
        if not self.enabled:
            return {"success": False, "message": "Supabase client not initialized. Enter Project URL and API Key."}
        try:
            res = self.client.table("stores").select("store_code").limit(1).execute()
            return {"success": True, "message": "Supabase Cloud Connected Successfully! Store Verified.", "data": res.data}
        except Exception as e:
            return {"success": False, "message": f"Connection test failed: {str(e)}"}

    def sync_local_data(self, local_db, current_inventory=None, current_shelf_audit=None, current_alerts=None):
        """
        Pushes unsynced offline records from SQLite to Supabase cloud tables:
        - shopper_traffic
        - queue_metrics
        - alerts
        - inventory_logs
        - shelf_compliance
        """
        if not self.enabled:
            return {"synced": False, "reason": "Cloud not connected"}

        self._ensure_store_exists()

        try:
            unsynced = local_db.get_unsynced_records(limit=40)
            synced_traffic_ids = []
            synced_queue_ids = []
            synced_alert_ids = []
            synced_shelf_ids = []
            now_iso = datetime.now().isoformat()

            # 1. Sync Shopper Traffic
            if unsynced["traffic"]:
                traffic_payloads = [{
                    "store_code": self.store_code,
                    "current_occupancy": r["current_people"],
                    "total_in": r["total_in"],
                    "total_out": r["total_out"],
                    "avg_dwell_time_seconds": r["avg_dwell_time"],
                    "timestamp": r["timestamp"] if "T" in str(r["timestamp"]) else now_iso
                } for r in unsynced["traffic"]]
                
                try:
                    self.client.table("shopper_traffic").insert(traffic_payloads).execute()
                    synced_traffic_ids = [r["id"] for r in unsynced["traffic"]]
                    self.synced_counts["traffic"] += len(traffic_payloads)
                except Exception as e:
                    print(f"[Supabase Sync Error: shopper_traffic]: {e}")

            # 2. Sync Queue Metrics
            if unsynced["queue"]:
                queue_payloads = [{
                    "store_code": self.store_code,
                    "queue_length": r["queue_length"],
                    "avg_wait_time_seconds": r["estimated_wait_sec"],
                    "is_congested": bool(r["is_congested"]),
                    "timestamp": r["timestamp"] if "T" in str(r["timestamp"]) else now_iso
                } for r in unsynced["queue"]]

                try:
                    self.client.table("queue_metrics").insert(queue_payloads).execute()
                    synced_queue_ids = [r["id"] for r in unsynced["queue"]]
                    self.synced_counts["queue"] += len(queue_payloads)
                except Exception as e:
                    print(f"[Supabase Sync Error: queue_metrics]: {e}")

            # 3. Sync Operational Alerts (Unsynced from DB + Live Alerts)
            alert_items_to_sync = []
            if unsynced["alerts"]:
                for r in unsynced["alerts"]:
                    ts = r.get("timestamp")
                    valid_ts = ts if (ts and "T" in str(ts)) else now_iso
                    alert_items_to_sync.append({
                        "store_code": self.store_code,
                        "alert_type": r["alert_type"],
                        "severity": r["severity"],
                        "title": r["title"],
                        "message": r["message"],
                        "zone": r["zone"],
                        "created_at": valid_ts
                    })
                synced_alert_ids = [r["id"] for r in unsynced["alerts"]]
            elif current_alerts:
                # If all SQLite items were synced, push latest active live alerts
                for a in current_alerts:
                    alert_items_to_sync.append({
                        "store_code": self.store_code,
                        "alert_type": a["type"],
                        "severity": a["severity"],
                        "title": a["title"],
                        "message": a["message"],
                        "zone": a.get("zone", ""),
                        "created_at": now_iso
                    })

            if alert_items_to_sync:
                try:
                    res = self.client.table("alerts").insert(alert_items_to_sync).execute()
                    self.synced_counts["alerts"] += len(alert_items_to_sync)
                    print(f"[Supabase Sync] Successfully inserted {len(alert_items_to_sync)} alerts into Supabase.")
                except Exception as e:
                    print(f"[Supabase Sync Error: alerts]: {e}")

            # 4. Sync Shelf Compliance
            shelf_items_to_sync = []
            if unsynced.get("shelf"):
                for r in unsynced["shelf"]:
                    ts = r.get("timestamp")
                    valid_ts = ts if (ts and "T" in str(ts)) else now_iso
                    shelf_items_to_sync.append({
                        "store_code": self.store_code,
                        "zone_name": r["zone_name"],
                        "detected_items": r["detected_items"],
                        "compliance_score": r["compliance_score"],
                        "status": r["status"],
                        "timestamp": valid_ts
                    })
                synced_shelf_ids = [r["id"] for r in unsynced["shelf"]]
            elif current_shelf_audit and "shelves" in current_shelf_audit:
                for s in current_shelf_audit["shelves"]:
                    shelf_items_to_sync.append({
                        "store_code": self.store_code,
                        "zone_name": s.get("zone"),
                        "detected_items": s.get("detected_count", 0),
                        "compliance_score": s.get("compliance_score", 100.0),
                        "status": s.get("status", "COMPLIANT"),
                        "timestamp": now_iso
                    })

            if shelf_items_to_sync:
                try:
                    self.client.table("shelf_compliance").insert(shelf_items_to_sync).execute()
                    self.synced_counts["shelf"] += len(shelf_items_to_sync)
                except Exception as e:
                    print(f"[Supabase Sync Error: shelf_compliance]: {e}")

            # 5. Sync Current Inventory Snapshot
            if current_inventory and "items" in current_inventory:
                inv_payloads = [{
                    "store_code": self.store_code,
                    "product_id": item["product_id"],
                    "product_name": item["product_name"],
                    "detected_count": item["stock"],
                    "minimum_stock": item["minimum_stock"],
                    "status": item["status"],
                    "shelf_zone": item.get("shelf_zone", ""),
                    "timestamp": now_iso
                } for item in current_inventory["items"]]

                try:
                    self.client.table("inventory_logs").insert(inv_payloads).execute()
                    self.synced_counts["inventory"] += len(inv_payloads)
                except Exception as e:
                    print(f"[Supabase Sync Error: inventory_logs]: {e}")

            # Mark synced in SQLite
            if synced_traffic_ids:
                local_db.mark_synced("traffic_history", synced_traffic_ids)
            if synced_queue_ids:
                local_db.mark_synced("queue_history", synced_queue_ids)
            if synced_alert_ids:
                local_db.mark_synced("alerts_log", synced_alert_ids)
            if synced_shelf_ids:
                local_db.mark_synced("shelf_compliance_history", synced_shelf_ids)

            self.last_sync_time = datetime.now().strftime("%H:%M:%S")
            self.last_sync_status = "Synchronized"

            return {
                "synced": True,
                "timestamp": self.last_sync_time,
                "counts": self.synced_counts
            }
        except Exception as e:
            self.last_sync_status = f"Sync Error: {str(e)}"
            print(f"[Supabase Sync Critical Error]: {e}")
            return {"synced": False, "error": str(e)}

    def get_status(self):
        return {
            "enabled": self.enabled,
            "url": self.url[:25] + "..." if len(self.url) > 25 else self.url,
            "has_key": bool(self.key),
            "status": self.last_sync_status,
            "last_sync_time": self.last_sync_time,
            "synced_counts": self.synced_counts
        }
