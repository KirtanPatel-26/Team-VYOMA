import sqlite3
import json
import time
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager

class LocalDatabase:
    """
    Offline-first SQLite database.
    Stores all edge retail intelligence events and metrics locally.
    Ensures complete business continuity in Tier-2/Tier-3 retail stores even during internet blackouts.
    """
    def __init__(self, db_path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_db()

    @contextmanager
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Events & Telemetry Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    synced INTEGER DEFAULT 0
                )
            """)

            # Shopper Footfall History Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS traffic_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    total_in INTEGER,
                    total_out INTEGER,
                    current_people INTEGER,
                    avg_dwell_time REAL,
                    synced INTEGER DEFAULT 0
                )
            """)

            # Queue History Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS queue_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    queue_length INTEGER,
                    estimated_wait_sec REAL,
                    is_congested INTEGER,
                    synced INTEGER DEFAULT 0
                )
            """)

            # Alerts Log Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS alerts_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alert_id TEXT UNIQUE,
                    alert_type TEXT,
                    severity TEXT,
                    title TEXT,
                    message TEXT,
                    zone TEXT,
                    timestamp TEXT,
                    synced INTEGER DEFAULT 0
                )
            """)

            # Shelf & Planogram Compliance History Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS shelf_compliance_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    zone_name TEXT,
                    detected_items INTEGER,
                    compliance_score REAL,
                    status TEXT,
                    synced INTEGER DEFAULT 0
                )
            """)

            conn.commit()

    def save_event(self, event_type, payload):
        timestamp = datetime.now().isoformat()
        with self.get_connection() as conn:
            conn.execute(
                "INSERT INTO events(timestamp, event_type, payload, synced) VALUES (?, ?, ?, 0)",
                (timestamp, event_type, json.dumps(payload))
            )
            conn.commit()

    def log_snapshot(self, traffic_data, queue_data, alerts_list, shelf_audit=None):
        timestamp = datetime.now().isoformat()
        with self.get_connection() as conn:
            # 1. Log Traffic
            conn.execute("""
                INSERT INTO traffic_history(timestamp, total_in, total_out, current_people, avg_dwell_time, synced)
                VALUES (?, ?, ?, ?, ?, 0)
            """, (
                timestamp,
                traffic_data.get("total_in", 0),
                traffic_data.get("total_out", 0),
                traffic_data.get("current_people", 0),
                traffic_data.get("avg_dwell_time", 0.0)
            ))

            # 2. Log Queue
            conn.execute("""
                INSERT INTO queue_history(timestamp, queue_length, estimated_wait_sec, is_congested, synced)
                VALUES (?, ?, ?, ?, 0)
            """, (
                timestamp,
                queue_data.get("queue_length", 0),
                queue_data.get("estimated_wait_time_sec", 0.0),
                1 if queue_data.get("congestion") else 0
            ))

            # 3. Log Alerts
            for a in alerts_list:
                conn.execute("""
                    INSERT OR REPLACE INTO alerts_log(alert_id, alert_type, severity, title, message, zone, timestamp, synced)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 0)
                """, (
                    a.get("id"),
                    a.get("type"),
                    a.get("severity"),
                    a.get("title"),
                    a.get("message"),
                    a.get("zone", ""),
                    a.get("iso_timestamp", timestamp)
                ))

            # 4. Log Shelf Compliance
            if shelf_audit and "shelves" in shelf_audit:
                for shelf in shelf_audit["shelves"]:
                    conn.execute("""
                        INSERT INTO shelf_compliance_history(timestamp, zone_name, detected_items, compliance_score, status, synced)
                        VALUES (?, ?, ?, ?, ?, 0)
                    """, (
                        timestamp,
                        shelf.get("zone"),
                        shelf.get("detected_count", 0),
                        shelf.get("compliance_score", 100.0),
                        shelf.get("status", "COMPLIANT")
                    ))

            conn.commit()

    def get_recent_history(self, limit=30):
        with self.get_connection() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            traffic = cursor.execute(
                "SELECT * FROM traffic_history ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            
            queue = cursor.execute(
                "SELECT * FROM queue_history ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            
            alerts = cursor.execute(
                "SELECT * FROM alerts_log ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

            return {
                "traffic": [dict(r) for r in reversed(traffic)],
                "queue": [dict(r) for r in reversed(queue)],
                "alerts": [dict(r) for r in alerts]
            }

    def get_unsynced_records(self, limit=50):
        with self.get_connection() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            traffic = cursor.execute("SELECT * FROM traffic_history WHERE synced = 0 LIMIT ?", (limit,)).fetchall()
            queue = cursor.execute("SELECT * FROM queue_history WHERE synced = 0 LIMIT ?", (limit,)).fetchall()
            alerts = cursor.execute("SELECT * FROM alerts_log WHERE synced = 0 LIMIT ?", (limit,)).fetchall()
            shelf = cursor.execute("SELECT * FROM shelf_compliance_history WHERE synced = 0 LIMIT ?", (limit,)).fetchall()

            return {
                "traffic": [dict(r) for r in traffic],
                "queue": [dict(r) for r in queue],
                "alerts": [dict(r) for r in alerts],
                "shelf": [dict(r) for r in shelf]
            }

    def mark_synced(self, table_name, ids):
        if not ids:
            return
        with self.get_connection() as conn:
            placeholders = ",".join("?" for _ in ids)
            conn.execute(f"UPDATE {table_name} SET synced = 1 WHERE id IN ({placeholders})", ids)
            conn.commit()
