import time

class QueueAnalytics:
    """
    Intelligent Queue Analytics & Predictive Congestion Manager:
    - Measures current queue length
    - Calculates estimated wait times
    - Predicts congestion thresholds
    - Provides proactive staffing recommendations (e.g. open extra counters)
    """
    def __init__(self, queue_zone=None, threshold=4, avg_service_time_sec=45.0):
        self.queue_zone = queue_zone or [850, 380, 1240, 680]
        self.threshold = threshold
        self.avg_service_time_sec = avg_service_time_sec
        self.active_counters = 1
        self.history = []

    def update(self, detections):
        if not self.queue_zone:
            return {
                "queue_length": 0,
                "active_counters": self.active_counters,
                "estimated_wait_time_sec": 0,
                "congestion": False,
                "recommendation": "All counters operating normally."
            }

        zx1, zy1, zx2, zy2 = self.queue_zone
        count = 0

        for d in detections:
            if d.class_name != "person":
                continue
            x1, y1, x2, y2 = d.bbox
            cx = (x1 + x2) / 2.0
            cy = (y1 + y2) / 2.0
            if zx1 <= cx <= zx2 and zy1 <= cy <= zy2:
                count += 1

        is_congested = count >= self.threshold
        estimated_wait_sec = (count * self.avg_service_time_sec) / max(1, self.active_counters)
        
        if is_congested:
            needed_counters = max(2, (count + 2) // 3)
            rec = f"High congestion ({count} customers waiting). Recommend opening Billing Counter {needed_counters} immediately to reduce wait time to {round(estimated_wait_sec / needed_counters / 60, 1)} min."
        elif count >= 3:
            rec = f"Moderate queue ({count} customers). Monitor closely."
        else:
            rec = "Queue flow is optimal. 1 Active Billing Counter sufficient."

        return {
            "queue_length": count,
            "active_counters": self.active_counters,
            "estimated_wait_time_sec": round(estimated_wait_sec, 1),
            "estimated_wait_time_min": round(estimated_wait_sec / 60.0, 1),
            "congestion": is_congested,
            "threshold": self.threshold,
            "recommendation": rec
        }
