// =========================================================
// SmartRetail AI - Comprehensive Dashboard Client
// =========================================================

let dwellChart = null;
let trafficTrendChart = null;
let queueTrendChart = null;
let currentAlertFilter = 'all';
let allAlerts = [];
let currentCamChannel = 1;

// Initialize Dashboard
document.addEventListener("DOMContentLoaded", () => {
  initCharts();
  fetchInitialData();
  fetchCameraSourceStatus();
  setInterval(fetchLiveStats, 1000);
  setInterval(fetchHistory, 5000);
  setInterval(fetchLedgerBlocks, 4000);
});

// Tab Switcher
function switchTab(tabId) {
  document.querySelectorAll(".tab-content").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".tab-btn").forEach(el => el.classList.remove("active"));

  const targetTab = document.getElementById(`tab-${tabId}`);
  if (targetTab) targetTab.classList.add("active");

  const activeBtn = Array.from(document.querySelectorAll(".tab-btn")).find(btn => 
    btn.getAttribute("onclick") && btn.getAttribute("onclick").includes(tabId)
  );
  if (activeBtn) activeBtn.classList.add("active");

  if (tabId === "traffic") {
    fetchHeatmapData();
  } else if (tabId === "ledger") {
    fetchLedgerBlocks();
  }
}

// Multi-Camera Switching
function switchCameraChannel(camNum) {
  currentCamChannel = camNum;
  document.querySelectorAll(".cam-btn").forEach(b => b.classList.remove("active"));
  const btn = Array.from(document.querySelectorAll(".cam-btn")).find(b => b.textContent.includes(`CAM 0${camNum}`));
  if (btn) btn.classList.add("active");

  reloadVideoFeed();
}

// ================= VIDEO FEED SOURCE MANAGEMENT =================
async function fetchCameraSourceStatus() {
  try {
    const res = await fetch("/api/camera/sources");
    if (!res.ok) return;
    const data = await res.json();
    updateSourceUI(data);
  } catch (err) {
    console.warn("Failed to fetch camera sources:", err);
  }
}

function updateSourceUI(data) {
  const btnWebcam = document.getElementById("btnSrcWebcam");
  const btnUpload = document.getElementById("btnSrcUpload");
  const btnDemo = document.getElementById("btnSrcDemo");
  const label = document.getElementById("activeSourceLabel");
  const badge = document.getElementById("activeSourceBadge");
  const cctvTitle = document.getElementById("cctvHeaderTitle");

  [btnWebcam, btnUpload, btnDemo].forEach(b => b && b.classList.remove("active"));

  if (data.is_webcam) {
    if (btnWebcam) btnWebcam.classList.add("active");
    if (label) label.textContent = `Webcam (Device ${data.active_source})`;
    if (badge) {
      badge.style.borderColor = "#06b6d4";
      badge.style.color = "#22d3ee";
    }
    if (cctvTitle) {
      cctvTitle.textContent = `Live Edge CCTV: Webcam (Device ${data.active_source}) Active`;
    }
  } else if (data.is_synthetic_demo) {
    if (btnDemo) btnDemo.classList.add("active");
    if (label) label.textContent = "Active: Demo Store";
    if (badge) {
      badge.style.borderColor = "rgba(16, 185, 129, 0.3)";
      badge.style.color = "#10b981";
    }
    if (cctvTitle) {
      cctvTitle.textContent = "Live Edge CCTV Stream (Demo Store Stream)";
    }
  } else {
    if (btnUpload) btnUpload.classList.add("active");
    const filename = String(data.active_source).split("/").pop().split("\\").pop();
    if (label) label.textContent = `Video: ${filename}`;
    if (badge) {
      badge.style.borderColor = "#f59e0b";
      badge.style.color = "#fbbf24";
    }
    if (cctvTitle) {
      cctvTitle.textContent = `Live Edge CCTV: Video (${filename})`;
    }
  }
}

async function activateWebcam() {
  const label = document.getElementById("activeSourceLabel");
  if (label) label.textContent = "Connecting to Webcam...";
  
  try {
    const res = await fetch("/api/camera/switch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source: 0 })
    });
    const result = await res.json();
    if (result.success) {
      fetchCameraSourceStatus();
      reloadVideoFeed();
    } else {
      alert("⚠️ Could not open Webcam (Device 0). Verify that a camera is plugged in and permissions are granted.");
      fetchCameraSourceStatus();
    }
  } catch (err) {
    alert("Network error connecting to webcam: " + err.message);
    fetchCameraSourceStatus();
  }
}

async function activateDemoVideo() {
  const label = document.getElementById("activeSourceLabel");
  if (label) label.textContent = "Loading Demo Stream...";
  
  try {
    const res = await fetch("/api/camera/switch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source: "videos/store.mp4" })
    });
    const result = await res.json();
    if (result.success) {
      fetchCameraSourceStatus();
      reloadVideoFeed();
    }
  } catch (err) {
    console.error("Error switching to demo store:", err);
  }
}

function triggerVideoUpload() {
  const input = document.getElementById("videoFileInput");
  if (input) input.click();
}

async function handleVideoFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;

  const status = document.getElementById("videoUploadStatus");
  if (status) {
    status.style.display = "inline";
    status.textContent = `Uploading ${file.name}...`;
  }

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("/api/camera/upload-video", {
      method: "POST",
      body: formData
    });
    const data = await res.json();

    if (data.success) {
      if (status) {
        status.textContent = `Uploaded!`;
        setTimeout(() => { status.style.display = "none"; }, 2500);
      }
      fetchCameraSourceStatus();
      reloadVideoFeed();
    } else {
      alert("⚠️ Upload failed: " + (data.error || "Unknown error"));
      if (status) status.style.display = "none";
    }
  } catch (err) {
    alert("Error uploading video: " + err.message);
    if (status) status.style.display = "none";
  } finally {
    event.target.value = "";
  }
}

function reloadVideoFeed() {
  const img = document.getElementById("liveFeedImg");
  if (img) {
    img.src = `/api/video/feed?cam=${currentCamChannel}&t=${Date.now()}`;
  }
}

// ================= FETCH LIVE REAL-TIME STATS =================
async function fetchLiveStats() {
  try {
    const res = await fetch("/api/live-stats");
    if (!res.ok) throw new Error("Network error");
    const data = await res.json();

    // 1. Edge & Cloud Status Header
    document.getElementById("edgeFps").textContent = `${data.fps || 30.0} FPS`;
    
    const cloudStatus = data.cloud_status || {};
    const cloudDot = document.getElementById("cloudDot");
    const cloudStatusText = document.getElementById("cloudStatusText");
    const cloudBadge = document.getElementById("cloudStatusBadge");
    const btnDisconnectHeader = document.getElementById("btnDisconnectHeader");

    if (cloudStatus.enabled) {
      cloudDot.className = "pulse-dot green";
      cloudStatusText.textContent = "CONNECTED";
      if (btnDisconnectHeader) btnDisconnectHeader.style.display = "inline-block";
      if (cloudBadge) {
        cloudBadge.textContent = "CONNECTED (LIVE SYNC ACTIVE)";
        cloudBadge.style.color = "#10b981";
      }
    } else {
      cloudDot.className = "pulse-dot amber";
      cloudStatusText.textContent = "OFFLINE";
      if (btnDisconnectHeader) btnDisconnectHeader.style.display = "none";
      if (cloudBadge) {
        cloudBadge.textContent = "OFFLINE (LOCAL SQLITE ACTIVE)";
        cloudBadge.style.color = "#f59e0b";
      }
    }

    // 2. Staff vs Customer Traffic Metrics
    const traffic = data.traffic || {};
    const queue = data.queue || {};
    const stock = data.stock || {};
    const shelfAudit = data.shelf_audit || {};
    const priceAudit = data.price_audit || [];
    const forecasts = data.forecasts || [];
    const alerts = data.alerts || [];

    const custCount = traffic.current_customers || 0;
    const staffCount = traffic.current_staff || 2;
    const staffRatio = traffic.customer_to_staff_ratio || "4.0 : 1";

    document.getElementById("kpiCustomers").textContent = custCount;
    document.getElementById("kpiTotalIn").textContent = traffic.total_in || 0;
    document.getElementById("kpiStaff").textContent = staffCount;
    document.getElementById("kpiStaffRatio").textContent = staffRatio;
    document.getElementById("headerStaffCount").textContent = `${staffCount} ON DUTY`;

    // Queue KPI
    const qLen = queue.queue_length || 0;
    document.getElementById("kpiQueue").textContent = `${qLen} Person${qLen === 1 ? '' : 's'}`;
    document.getElementById("kpiWaitTime").textContent = `${queue.estimated_wait_time_min || 0.0}m`;
    
    const qStatus = document.getElementById("kpiQueueStatus");
    if (queue.congestion) {
      qStatus.textContent = `● High Congestion (${qLen} in line)`;
      qStatus.className = "kpi-footer text-rose";
    } else {
      qStatus.textContent = `● Flow is optimal (${qLen} in line)`;
      qStatus.className = "kpi-footer text-emerald";
    }

    // Stock KPI
    document.getElementById("kpiStockHealth").textContent = `${stock.stock_health_score || 100}%`;
    const oosCount = (stock.items || []).filter(i => i.status === "OUT_OF_STOCK").length;
    document.getElementById("kpiOosCount").textContent = oosCount;

    // Price Audit KPI
    const mismatchCount = priceAudit.filter(p => p.is_mismatch).length;
    document.getElementById("kpiPriceAudit").textContent = `${priceAudit.length - mismatchCount}/${priceAudit.length || 8}`;
    document.getElementById("kpiPriceMismatch").textContent = mismatchCount;

    // Alerts KPI
    document.getElementById("kpiAlerts").textContent = alerts.length;
    const criticalCount = alerts.filter(a => a.severity === "critical").length;
    document.getElementById("kpiCritical").textContent = criticalCount;
    document.getElementById("tabAlertCount").textContent = alerts.length;

    // 2b. Business Impact Financial & Operational KPIs
    const roi = data.business_impact || {};
    const roiProtElem = document.getElementById("roiProtectedVal");
    if (roiProtElem) roiProtElem.textContent = `₹${Math.round(roi.revenue_protected_today || 0).toLocaleString()}`;

    const roiLostElem = document.getElementById("roiLostVal");
    if (roiLostElem) roiLostElem.textContent = `₹${Math.round(roi.total_estimated_lost_sales_today || 0).toLocaleString()}`;

    const roiLostBreakdown = document.getElementById("roiLostBreakdown");
    if (roiLostBreakdown) {
      roiLostBreakdown.textContent = `● Stockouts: ₹${Math.round(roi.lost_sales_stockout_today || 0)} | Queue: ₹${Math.round(roi.lost_sales_queue_today || 0)}`;
    }

    const roiHoursElem = document.getElementById("roiHoursSaved");
    if (roiHoursElem) roiHoursElem.textContent = `${roi.staff_hours_saved_today || 0}h`;

    const roiStockRedElem = document.getElementById("roiStockoutReduction");
    if (roiStockRedElem) roiStockRedElem.textContent = `+${roi.stockout_reduction_pct || 34.0}%`;

    // 3. Operational Advice & Store Brain Directives
    const recText = document.getElementById("overviewRecText");
    if (queue.recommendation) {
      recText.textContent = queue.recommendation;
    }

    const brain = data.brain || {};
    renderStoreBrainDirectives(brain);

    renderOverviewAlerts(alerts);
    document.getElementById("overviewCompliance").textContent = `${shelfAudit.overall_compliance_score || 100}%`;
    document.getElementById("overviewComplianceBar").style.width = `${shelfAudit.overall_compliance_score || 100}%`;

    // 4. Render Tables & Views
    renderInventoryTable(stock.items || []);
    renderPriceOcrTable(priceAudit);
    renderPlanogramAudit(shelfAudit.shelves || []);
    renderForecasterTable(forecasts);

    // 5. Queue Tab
    document.getElementById("queueHeroCount").textContent = qLen;
    document.getElementById("queueHeroWait").textContent = `${queue.estimated_wait_time_min || 0.0} mins`;
    document.getElementById("queueRecMessage").textContent = queue.recommendation || "Queue operating normally.";

    // 6. Full Alerts Tab
    allAlerts = alerts;
    renderFullAlerts(alerts);

    // 7. Sync Telemetry Counts
    if (cloudStatus.synced_counts) {
      document.getElementById("syncCountTraffic").textContent = cloudStatus.synced_counts.traffic || 0;
      document.getElementById("syncCountInventory").textContent = cloudStatus.synced_counts.inventory || 0;
      document.getElementById("syncCountQueue").textContent = cloudStatus.synced_counts.queue || 0;
      document.getElementById("syncCountAlerts").textContent = cloudStatus.synced_counts.alerts || 0;
      if (document.getElementById("syncCountShelf")) {
        document.getElementById("syncCountShelf").textContent = cloudStatus.synced_counts.shelf || 0;
      }
    }

  } catch (err) {
    console.warn("Live stats polling error:", err);
  }
}

// ================= AI RETAIL COPILOT =================
async function sendCopilotQuery(queryText) {
  const chatBox = document.getElementById("copilotChatBox");
  
  // User bubble
  const userMsg = document.createElement("div");
  userMsg.className = "chat-message user";
  userMsg.innerHTML = `<div class="chat-sender">Store Manager</div><div class="chat-bubble">${escapeHtml(queryText)}</div>`;
  chatBox.appendChild(userMsg);
  chatBox.scrollTop = chatBox.scrollHeight;

  // Bot loading placeholder
  const botMsg = document.createElement("div");
  botMsg.className = "chat-message bot";
  botMsg.innerHTML = `<div class="chat-sender">🤖 Retail Copilot</div><div class="chat-bubble">Thinking & synthesizing live store state...</div>`;
  chatBox.appendChild(botMsg);
  chatBox.scrollTop = chatBox.scrollHeight;

  try {
    const res = await fetch("/api/copilot/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: queryText })
    });
    const data = await res.json();
    botMsg.querySelector(".chat-bubble").innerHTML = formatMarkdownText(data.response);
    chatBox.scrollTop = chatBox.scrollHeight;
  } catch (err) {
    botMsg.querySelector(".chat-bubble").textContent = "Sorry, unable to query live store data right now.";
  }
}

function handleCopilotSubmit(e) {
  e.preventDefault();
  const input = document.getElementById("copilotInput");
  const q = input.value.trim();
  if (q) {
    sendCopilotQuery(q);
    input.value = "";
  }
}

function formatMarkdownText(text) {
  if (!text) return "";
  let html = escapeHtml(text);
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
  html = html.replace(/`(.*?)`/g, '<code>$1</code>');
  return html;
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// ================= HASHGRAPH LEDGER EXPLORER =================
async function fetchLedgerBlocks() {
  try {
    const res = await fetch("/api/ledger/blocks?limit=15");
    const data = await res.json();
    const container = document.getElementById("ledgerBlocksList");
    if (!container || !data.blocks) return;

    document.getElementById("ledgerBlockCount").textContent = data.total_blocks || 0;

    container.innerHTML = data.blocks.map(b => `
      <div class="ledger-block-card">
        <div class="l-block-head">
          <span class="l-seq">Block #${b.sequence_number}</span>
          <span class="l-type">${b.event_type}</span>
          <span class="status-badge match">CONSENSUS VERIFIED</span>
        </div>
        <div style="font-size: 12px; color: #d1d5db; margin: 4px 0;">
          <strong>Payload:</strong> ${JSON.stringify(b.payload)}
        </div>
        <div class="l-hash">
          <strong>SHA-256 Hash:</strong> ${b.hash}
        </div>
      </div>
    `).join("");
  } catch (err) {
    console.warn("Ledger fetch error:", err);
  }
}

async function verifyLedgerIntegrity() {
  try {
    const res = await fetch("/api/ledger/verify");
    const data = await res.json();
    if (data.valid) {
      alert(`🛡️ Cryptographic Integrity Verified!\n\n• Total Blocks Checked: ${data.total_blocks}\n• Consensus Status: ${data.consensus_status}\n• Latest Hash: ${data.latest_hash}`);
    } else {
      alert(`⚠️ Chain Verification Alert: ${data.message}`);
    }
  } catch (err) {
    alert("Verification failed: " + err.message);
  }
}

// ================= PREDICTIVE FORECASTER TABLE =================
function renderForecasterTable(forecasts) {
  const tbody = document.getElementById("forecasterTableBody");
  if (!tbody || !forecasts || forecasts.length === 0) return;

  tbody.innerHTML = forecasts.map(f => {
    let riskBadge = `<span class="status-badge match">OPTIMAL</span>`;
    if (f.urgency.includes("CRITICAL")) {
      riskBadge = `<span class="status-badge out-of-stock">DEPLETED (0 MINS)</span>`;
    } else if (f.urgency.includes("HIGH")) {
      riskBadge = `<span class="status-badge low-stock">HIGH RISK</span>`;
    }

    return `
      <tr>
        <td><strong>${f.product_name}</strong></td>
        <td><code>${f.current_stock} units</code></td>
        <td>${f.depletion_velocity} units / min</td>
        <td><strong style="color: ${f.estimated_minutes_remaining < 15 ? '#fb7185' : '#67e8f9'};">${f.estimated_minutes_remaining} mins</strong></td>
        <td>${riskBadge}</td>
        <td><strong>${f.recommended_restock_units} units</strong></td>
        <td style="color: #fb7185;">₹${f.projected_revenue_loss.toFixed(2)}</td>
      </tr>
    `;
  }).join("");
}

// ================= DIRECT STAFF PHONE DISPATCH & WHATSAPP =================
function openStaffPhoneModal() {
  document.getElementById("staffPhoneModal").style.display = "flex";
}

function closeStaffPhoneModal() {
  document.getElementById("staffPhoneModal").style.display = "none";
}

function updateStaffPhoneField() {
  const select = document.getElementById("staffPhoneSelect");
  const customGroup = document.getElementById("customPhoneGroup");
  if (select.value === "custom") {
    customGroup.style.display = "block";
  } else {
    customGroup.style.display = "none";
  }
}

function insertMessageTemplate(type) {
  const textarea = document.getElementById("staffMessageText");
  if (type === "oos") {
    textarea.value = "🚨 URGENT RESTOCK ORDER: Fanta Orange, Real Juice, and Amul Milk are depleted on Shelves B & C. Please restock immediately from back-room inventory!";
  } else if (type === "queue") {
    textarea.value = "🛒 QUEUE CONGESTION ALERT: 6+ customers in line at Billing Counter 1. Please open Counter 2 immediately to reduce customer wait time!";
  } else if (type === "price") {
    textarea.value = "🔍 PRICE TAG MISMATCH: EasyOCR detected Coca Cola shelf tag displays Rs 99, but POS system price is Rs 40. Please update shelf label!";
  }
}

function getSelectedStaffPhoneAndName() {
  const select = document.getElementById("staffPhoneSelect");
  let phone = select.value;
  let name = select.options[select.selectedIndex].getAttribute("data-name") || "Staff Member";
  
  if (phone === "custom") {
    phone = document.getElementById("customPhoneInput").value.trim();
    name = "Custom Staff (" + phone + ")";
  }
  return { phone, name };
}

// 1. Direct WhatsApp to Staff Phone
function sendWhatsAppToStaff() {
  const { phone, name } = getSelectedStaffPhoneAndName();
  const message = document.getElementById("staffMessageText").value.trim();
  if (!message) {
    alert("Please enter a message to send.");
    return;
  }

  // Clean phone string
  const cleanPhone = phone.replace(/[^0-9]/g, "");
  const encodedMsg = encodeURIComponent(message);
  const whatsappUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}`;

  // Log dispatch in background to Hashgraph
  fetch("/api/staff/notify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: cleanPhone, staff: name, message: message, channel: "whatsapp" })
  }).catch(() => {});

  // Open WhatsApp in new tab
  window.open(whatsappUrl, "_blank");
  closeStaffPhoneModal();
}

// 2. Direct Server-Side Notification & Hashgraph Logging
async function submitDirectStaffNotification() {
  const { phone, name } = getSelectedStaffPhoneAndName();
  const message = document.getElementById("staffMessageText").value.trim();
  if (!message) {
    alert("Please enter a message to send.");
    return;
  }

  try {
    const res = await fetch("/api/staff/notify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone, staff: name, message })
    });
    const data = await res.json();
    alert(`✅ Message Dispatched to ${data.staff} (${data.phone})!\n\nMessage: "${data.message}"\n\n🛡️ Signed & Logged to Hashgraph Ledger\nBlock Hash: ${data.ledger_block_hash.substring(0, 20)}...`);
    closeStaffPhoneModal();
    fetchLedgerBlocks();
  } catch (err) {
    alert("Dispatch error: " + err.message);
  }
}

// ================= EXECUTIVE PDF & CSV REPORTS =================
function downloadPdfReport() {
  window.open("/api/reports/pdf?autoprint=true", "_blank");
}

function downloadExecutiveReport() {
  window.open("/api/reports/download", "_blank");
}

// Render Overview Mini Alerts
function renderOverviewAlerts(alerts) {
  const container = document.getElementById("overviewAlertsList");
  if (!alerts || alerts.length === 0) {
    container.innerHTML = `<div class="empty-state">No active incidents detected. Store operating smoothly.</div>`;
    return;
  }

  container.innerHTML = alerts.map(a => `
    <div class="alert-item-card ${a.severity}">
      <div>
        <div class="alert-item-title">${a.title}</div>
        <div class="alert-item-desc">${a.message}</div>
        <div class="alert-item-action">👉 ${a.action}</div>
      </div>
      <button class="btn-ack" onclick="acknowledgeAlert('${a.id}')">Acknowledge</button>
    </div>
  `).join("");
}

// Render Inventory Table
function renderInventoryTable(items) {
  const tbody = document.getElementById("inventoryTableBody");
  if (!items || items.length === 0) return;

  tbody.innerHTML = items.map(item => {
    let badgeClass = "in-stock";
    let badgeLabel = "IN STOCK";

    if (item.status === "OUT_OF_STOCK") {
      badgeClass = "out-of-stock";
      badgeLabel = "OUT OF STOCK";
    } else if (item.status === "LOW_STOCK") {
      badgeClass = "low-stock";
      badgeLabel = "LOW STOCK";
    }

    return `
      <tr>
        <td><code>${item.product_id}</code></td>
        <td><strong>${item.product_name}</strong></td>
        <td>${item.shelf_zone}</td>
        <td><strong style="font-family: var(--font-mono); font-size: 15px;">${item.stock}</strong> units</td>
        <td>${item.minimum_stock} units</td>
        <td><span class="status-badge ${badgeClass}">${badgeLabel}</span></td>
        <td>₹${item.total_value.toFixed(2)}</td>
      </tr>
    `;
  }).join("");
}

// Render EasyOCR Price Verification Table
function renderPriceOcrTable(priceAudit) {
  const tbody = document.getElementById("priceOcrTableBody");
  if (!tbody || !priceAudit || priceAudit.length === 0) return;

  tbody.innerHTML = priceAudit.map(p => {
    let badge = p.is_mismatch 
      ? `<span class="status-badge mismatch">MISMATCH (₹${p.detected_shelf_price})</span>`
      : `<span class="status-badge match">MATCH (100%)</span>`;

    return `
      <tr>
        <td><strong>${p.product_name}</strong></td>
        <td><code style="color: ${p.is_mismatch ? '#fb7185' : '#67e8f9'}">₹${p.detected_shelf_price.toFixed(2)}</code></td>
        <td><code>₹${p.catalog_price.toFixed(2)}</code></td>
        <td>${badge}</td>
      </tr>
    `;
  }).join("");
}

// Render Planogram Audit
function renderPlanogramAudit(shelves) {
  const container = document.getElementById("planogramAuditList");
  if (!shelves || shelves.length === 0) return;

  container.innerHTML = shelves.map(s => {
    let scoreColor = s.compliance_score >= 80 ? "text-emerald" : (s.compliance_score >= 50 ? "text-amber" : "text-rose");
    return `
      <div class="planogram-shelf-card">
        <div class="pshelf-header">
          <span class="pshelf-title">${s.zone} (${s.shelf_code})</span>
          <span class="${scoreColor}" style="font-weight: 800;">${s.compliance_score}% Compliant</span>
        </div>
        <div class="pshelf-details">
          <div><strong>Expected SKUs:</strong> ${s.expected_items.join(", ") || "None"}</div>
          <div><strong>Detected Items:</strong> ${s.detected_items.join(", ") || "Empty Shelf Slot"}</div>
          ${s.misplaced_items.length ? `<div style="color: var(--accent-rose);">⚠️ Misplaced: ${s.misplaced_items.join(", ")}</div>` : ''}
        </div>
      </div>
    `;
  }).join("");
}

// Render Full Alerts Center
function renderFullAlerts(alerts) {
  const container = document.getElementById("alertsFullContainer");
  let filtered = alerts;
  if (currentAlertFilter === "critical") {
    filtered = alerts.filter(a => a.severity === "critical");
  } else if (currentAlertFilter === "warning") {
    filtered = alerts.filter(a => a.severity === "warning");
  }

  if (!filtered || filtered.length === 0) {
    container.innerHTML = `<div class="empty-state">No matching alerts in this category. Store operating smoothly.</div>`;
    return;
  }

  container.innerHTML = filtered.map(a => `
    <div class="alert-item-card ${a.severity}" style="margin-bottom: 12px;">
      <div>
        <div class="alert-item-title">${a.title} <span style="font-size: 11px; font-weight: normal; opacity: 0.7;">• ${a.timestamp}</span></div>
        <div class="alert-item-desc">${a.message}</div>
        <div class="alert-item-action">👉 Action: ${a.action}</div>
      </div>
      <button class="btn-ack" onclick="acknowledgeAlert('${a.id}')">Mark Resolved</button>
    </div>
  `).join("");
}

function filterAlerts(type) {
  currentAlertFilter = type;
  document.querySelectorAll(".btn-filter").forEach(b => b.classList.remove("active"));
  const btn = Array.from(document.querySelectorAll(".btn-filter")).find(b => b.textContent.toLowerCase().includes(type));
  if (btn) btn.classList.add("active");
  renderFullAlerts(allAlerts);
}

// Acknowledge Alert
async function acknowledgeAlert(alertId) {
  try {
    await fetch(`/api/alerts/${alertId}/acknowledge`, { method: "POST" });
    fetchLiveStats();
  } catch (err) {
    console.error("Failed to acknowledge alert:", err);
  }
}

// ================= 2D HEATMAP CANVAS RENDERER =================
async function fetchHeatmapData() {
  try {
    const res = await fetch("/api/traffic/heatmap");
    const data = await res.json();
    drawHeatmap(data.heatmap_grid, data.dimensions);
    updateDwellChart(data.zone_dwell_summary);
  } catch (err) {
    console.error("Heatmap fetch error:", err);
  }
}

function drawHeatmap(grid, dimensions) {
  const canvas = document.getElementById("heatmapCanvas");
  if (!canvas || !grid || grid.length === 0) return;
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;

  ctx.clearRect(0, 0, width, height);

  // Background retail floor tiles
  ctx.fillStyle = "#0c1322";
  ctx.fillRect(0, 0, width, height);

  const rows = dimensions.rows || 20;
  const cols = dimensions.cols || 36;
  const cellW = width / cols;
  const cellH = height / rows;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const val = grid[r] ? grid[r][c] : 0;
      if (val > 0.02) {
        let rColor, gColor, bColor, alpha;
        alpha = Math.min(0.85, val * 1.2);

        if (val < 0.25) {
          rColor = 6; gColor = 182; bColor = 212;
        } else if (val < 0.5) {
          rColor = 16; gColor = 185; bColor = 129;
        } else if (val < 0.75) {
          rColor = 245; gColor = 158; bColor = 11;
        } else {
          rColor = 244; gColor = 63; bColor = 94;
        }

        ctx.fillStyle = `rgba(${rColor}, ${gColor}, ${bColor}, ${alpha})`;
        ctx.beginPath();
        ctx.arc(c * cellW + cellW / 2, r * cellH + cellH / 2, cellW * 1.4, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
}

// ================= CHARTS INITIALIZATION =================
function initCharts() {
  const ctxDwell = document.getElementById("dwellBarChart").getContext("2d");
  dwellChart = new Chart(ctxDwell, {
    type: "bar",
    data: {
      labels: ["Snacks & Biscuits", "Beverages & Drinks", "Dairy & Essentials", "Checkout Queue"],
      datasets: [{
        label: "Total Dwell Time (Seconds)",
        data: [45, 80, 35, 120],
        backgroundColor: ["rgba(245, 158, 11, 0.6)", "rgba(6, 182, 212, 0.6)", "rgba(16, 185, 129, 0.6)", "rgba(244, 63, 94, 0.6)"],
        borderColor: ["#f59e0b", "#06b6d4", "#10b981", "#f43f5e"],
        borderWidth: 1,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: "#9ca3af" }, grid: { display: false } },
        y: { ticks: { color: "#9ca3af" }, grid: { color: "rgba(255,255,255,0.05)" } }
      }
    }
  });

  const ctxTraffic = document.getElementById("trafficTrendChart").getContext("2d");
  trafficTrendChart = new Chart(ctxTraffic, {
    type: "line",
    data: {
      labels: ["-5m", "-4m", "-3m", "-2m", "-1m", "Now"],
      datasets: [
        {
          label: "Customers IN",
          data: [2, 4, 5, 7, 8, 8],
          borderColor: "#06b6d4",
          backgroundColor: "rgba(6, 182, 212, 0.1)",
          fill: true,
          tension: 0.4
        },
        {
          label: "Customers Active",
          data: [2, 3, 4, 6, 7, 8],
          borderColor: "#10b981",
          tension: 0.4
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#9ca3af" } } },
      scales: {
        x: { ticks: { color: "#9ca3af" }, grid: { display: false } },
        y: { ticks: { color: "#9ca3af" }, grid: { color: "rgba(255,255,255,0.05)" } }
      }
    }
  });

  const ctxQueue = document.getElementById("queueTrendChart").getContext("2d");
  queueTrendChart = new Chart(ctxQueue, {
    type: "line",
    data: {
      labels: ["-5m", "-4m", "-3m", "-2m", "-1m", "Now"],
      datasets: [
        {
          label: "Queue Length (Persons)",
          data: [1, 2, 3, 4, 5, 6],
          borderColor: "#f43f5e",
          backgroundColor: "rgba(244, 63, 94, 0.1)",
          fill: true,
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#9ca3af" } } },
      scales: {
        x: { ticks: { color: "#9ca3af" }, grid: { display: false } },
        y: { ticks: { color: "#9ca3af" }, grid: { color: "rgba(255,255,255,0.05)" }, min: 0 }
      }
    }
  });
}

function updateDwellChart(dwellSummary) {
  if (!dwellChart || !dwellSummary) return;
  const labels = Object.keys(dwellSummary);
  const values = Object.values(dwellSummary);
  if (labels.length > 0) {
    dwellChart.data.labels = labels;
    dwellChart.data.datasets[0].data = values;
    dwellChart.update();
  }
}

async function fetchHistory() {
  try {
    const res = await fetch("/api/history?limit=15");
    const data = await res.json();
    if (data.traffic && data.traffic.length > 0 && trafficTrendChart) {
      const labels = data.traffic.map(t => t.timestamp.split("T")[1].substring(0, 8));
      trafficTrendChart.data.labels = labels;
      trafficTrendChart.data.datasets[0].data = data.traffic.map(t => t.total_in);
      trafficTrendChart.data.datasets[1].data = data.traffic.map(t => t.current_people);
      trafficTrendChart.update();
    }
    if (data.queue && data.queue.length > 0 && queueTrendChart) {
      const labels = data.queue.map(q => q.timestamp.split("T")[1].substring(0, 8));
      queueTrendChart.data.labels = labels;
      queueTrendChart.data.datasets[0].data = data.queue.map(q => q.queue_length);
      queueTrendChart.update();
    }
  } catch (err) {
    // console.warn("History fetch error:", err);
  }
}

async function fetchSystemStatus() {
  try {
    const res = await fetch("/api/status");
    if (!res.ok) return;
    const data = await res.json();
    const modePill = document.getElementById("modePillHeader");
    const modeText = document.getElementById("modeTextHeader");
    const modeDot = document.getElementById("modeDotHeader");
    if (data.detection_mode === "TRAINED_MODEL") {
      if (modePill) {
        modePill.style.borderColor = "#10b981";
        modePill.style.background = "rgba(16, 185, 129, 0.15)";
        modePill.style.color = "#34d399";
      }
      if (modeDot) modeDot.style.background = "#34d399";
      if (modeText) modeText.textContent = "TRAINED MODEL";
    } else {
      if (modePill) {
        modePill.style.borderColor = "#f59e0b";
        modePill.style.background = "rgba(245, 158, 11, 0.15)";
        modePill.style.color = "#fbbf24";
      }
      if (modeDot) modeDot.style.background = "#fbbf24";
      if (modeText) modeText.textContent = "DEMO SIMULATION";
    }
  } catch (e) {}
}

async function fetchInitialData() {
  fetchSystemStatus();
  fetchLiveStats();
  fetchHeatmapData();
  fetchHistory();
  fetchLedgerBlocks();
}

// ================= SUPABASE ACTIONS =================
function openSupabaseModal() {
  document.getElementById("supabaseModal").style.display = "flex";
}

function closeSupabaseModal() {
  document.getElementById("supabaseModal").style.display = "none";
}

async function saveModalSupabase() {
  const url = document.getElementById("modalSbUrl").value.trim();
  const key = document.getElementById("modalSbKey").value.trim();
  await sendSupabaseConfig(url, key);
  closeSupabaseModal();
}

async function saveSupabaseConfig(e) {
  e.preventDefault();
  const url = document.getElementById("sbUrlInput").value.trim();
  const key = document.getElementById("sbKeyInput").value.trim();
  await sendSupabaseConfig(url, key);
}

async function sendSupabaseConfig(url, key) {
  try {
    const res = await fetch("/api/supabase/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, key })
    });
    const data = await res.json();
    alert(data.success ? "✅ Supabase Cloud Connected Successfully!" : "Connection configuration updated.");
    fetchLiveStats();
  } catch (err) {
    alert("Failed to configure Supabase: " + err.message);
  }
}

async function disconnectFromSupabase() {
  try {
    const res = await fetch("/api/supabase/disconnect", { method: "POST" });
    const data = await res.json();
    alert(data.message || "Disconnected from Supabase Cloud.");
    document.getElementById("sbUrlInput").value = "";
    document.getElementById("sbKeyInput").value = "";
    fetchLiveStats();
  } catch (err) {
    alert("Failed to disconnect: " + err.message);
  }
}

async function testSupabaseConnection() {
  const resultBox = document.getElementById("cloudTestResult");
  resultBox.style.display = "block";
  resultBox.textContent = "Testing Supabase Cloud connection...";
  resultBox.style.background = "rgba(6, 182, 212, 0.1)";
  resultBox.style.color = "#06b6d4";

  try {
    const res = await fetch("/api/supabase/test");
    const data = await res.json();
    if (data.success) {
      resultBox.textContent = "✅ " + data.message;
      resultBox.style.background = "rgba(16, 185, 129, 0.15)";
      resultBox.style.color = "#34d399";
    } else {
      resultBox.textContent = "❌ " + data.message;
      resultBox.style.background = "rgba(244, 63, 94, 0.15)";
      resultBox.style.color = "#fb7185";
    }
  } catch (err) {
    resultBox.textContent = "❌ Error connecting to test endpoint: " + err.message;
  }
}

async function triggerManualSync() {
  try {
    const res = await fetch("/api/supabase/sync", { method: "POST" });
    const data = await res.json();
    if (data.synced) {
      alert(`✅ Cloud Sync Successful at ${data.timestamp}!\n\nSynced to Supabase:\n• Traffic logs: ${data.counts.traffic}\n• Queue records: ${data.counts.queue}\n• Shelf compliance: ${data.counts.shelf}\n• Live alerts: ${data.counts.alerts}\n• Inventory logs: ${data.counts.inventory}`);
    } else {
      alert(`⚠️ Sync notice: ${data.reason || data.error || 'Check Supabase credentials.'}`);
    }
    fetchLiveStats();
  } catch (err) {
    alert("Sync request failed: " + err.message);
  }
}

// ================= STORE BRAIN DIRECTIVES =================
function renderStoreBrainDirectives(brain) {
  const container = document.getElementById("brainDirectivesList");
  const badge = document.getElementById("brainSurgeBadge");
  if (!container) return;

  if (badge) {
    const surge = brain.traffic_surge_pct || 0;
    badge.textContent = `Footfall Surge: ${surge >= 0 ? '+' : ''}${surge}%`;
    badge.style.color = surge > 15 ? '#fbbf24' : '#94a3b8';
  }

  const actions = brain.top_prioritized_actions || [];
  if (actions.length === 0) {
    container.innerHTML = `<div style="color: #10b981; font-size: 11px; padding: 4px;">✅ Store operations optimal. No urgent replenishment directives.</div>`;
    return;
  }

  container.innerHTML = actions.slice(0, 3).map((a, idx) => {
    const isCrit = a.priority === 1;
    const badgeColor = isCrit ? '#f43f5e' : '#fbbf24';
    const badgeBg = isCrit ? 'rgba(244,63,94,0.15)' : 'rgba(245,158,11,0.15)';
    const revText = a.revenue_at_risk ? `• ₹${Math.round(a.revenue_at_risk)} at risk` : '';

    return `
      <div style="background: rgba(0,0,0,0.35); border-left: 3px solid ${badgeColor}; border-radius: 6px; padding: 8px 10px; font-size: 11px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 2px;">
          <span style="font-weight: 700; color: #f8fafc;">${idx + 1}. [${escapeHtml(a.type)}] ${escapeHtml(a.action)}</span>
          <span style="font-size: 9px; font-weight: 700; padding: 2px 6px; border-radius: 4px; background:${badgeBg}; color:${badgeColor}; font-family:'JetBrains Mono'; white-space:nowrap; margin-left:6px;">
            ${isCrit ? 'URGENT' : 'PRIORITY 2'}
          </span>
        </div>
        <div style="display:flex; justify-content:space-between; color:#94a3b8; font-size: 10px; margin-top: 4px;">
          <span>Target: <code>${escapeHtml(a.target)}</code> (${escapeHtml(a.zone)})</span>
          <span style="color:#fbbf24; font-family:'JetBrains Mono';">Deadline: ${a.deadline_mins}m ${revText}</span>
        </div>
      </div>
    `;
  }).join("");
}

// ================= SYSTEM INTEGRITY MODAL =================
async function openIntegrityModal() {
  const modal = document.getElementById("integrityModal");
  if (!modal) return;
  modal.style.display = "flex";
  try {
    const res = await fetch("/api/integrity");
    if (res.ok) {
      const data = await res.json();
      const list = document.getElementById("integrityGrid");
      if (list && data.components) {
        list.innerHTML = data.components.map(c => `
          <div style="background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 12px;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 6px;">
              <strong style="font-size: 13px; color: #f8fafc;">${escapeHtml(c.module)}</strong>
              <span style="font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 12px; font-family:'JetBrains Mono'; ${
                c.source === 'REAL_NEURAL_NET' || c.source === 'TRAINED_MODEL' ? 'background:rgba(16,185,129,0.15); color:#34d399; border:1px solid #10b981;' :
                c.source === 'REAL_EDGE_ANALYTICS' || c.source === 'REAL_EDGE_OCR' ? 'background:rgba(56,189,248,0.15); color:#38bdf8; border:1px solid #38bdf8;' :
                c.source.includes('HEURISTIC') ? 'background:rgba(245,158,11,0.15); color:#fbbf24; border:1px solid #f59e0b;' :
                'background:rgba(148,163,184,0.15); color:#94a3b8; border:1px solid rgba(255,255,255,0.2);'
              }">${escapeHtml(c.source)}</span>
            </div>
            <div style="font-size: 11px; color: #94a3b8; margin-bottom: 6px;">${escapeHtml(c.description)}</div>
            <div style="display:flex; justify-content:space-between; font-size: 10px; color: #64748b; font-family:'JetBrains Mono';">
              <span>Method: ${escapeHtml(c.method)}</span>
              <span>Latency: ${escapeHtml(c.latency)}</span>
            </div>
          </div>
        `).join("");
      }
    }
  } catch (err) {
    console.warn("Integrity fetch failed:", err);
  }
}

function closeIntegrityModal() {
  const modal = document.getElementById("integrityModal");
  if (modal) modal.style.display = "none";
}

